const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String }, // Убедись, что это поле есть
  dueDate: { type: Date },
  priority: { type: String },
  category: { type: String },
  userId: { type: String, required: true },
  start: { type: Date },
  end: { type: Date },
});

module.exports = mongoose.model('Task', TaskSchema);