const express = require('express');
const router = express.Router();
const User = require('../models/User');
const argon2 = require('argon2');
const jwt = require('jsonwebtoken');
require('dotenv').config();

router.post('/register', async (req, res) => {
  console.log('Handling POST /register:', req.body);
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: 'Username already exists' });
    }
    const hashedPassword = await argon2.hash(password);
    console.log('Hashed password on register:', hashedPassword);
    const user = new User({ username, password: hashedPassword });
    await user.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/login', async (req, res) => {
  console.log('Handling POST /login:', req.body);
  try {
    const { username, password } = req.body;
    console.log('Finding user with username:', username);
    const user = await User.findOne({ username });
    console.log('Found user:', user);
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    console.log('Comparing passwords...');
    const isMatch = await argon2.verify(user.password, password);
    console.log('Password match:', isMatch);
    if (!isMatch) {
      const testHash = await argon2.hash(password);
      console.log('Test hash of entered password:', testHash);
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    console.log('Generated token:', token);
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production' });
    res.json({ message: 'Login successful', user: { id: user._id, username } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/test-password', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    const isMatch = await argon2.verify(user.password, password);
    const testHash = await argon2.hash(password);
    res.json({ matches: isMatch, storedHash: user.password, testHash: testHash });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

router.get('/me', (req, res) => {
  console.log('Handling GET /me');
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: 'No token provided' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    res.json({ userId: decoded.userId });
  } catch (err) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

router.post('/logout', (req, res) => {
  console.log('Handling POST /logout');
  res.clearCookie('token');
  res.json({ message: 'Logout successful' });
});

module.exports = router;