const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const authMiddleware = require('../middleware/authMiddleware');

// Получить задачи текущего пользователя
router.get('/', authMiddleware, async (req, res) => {
  try {
    const tasks = await Task.find({ userId: req.user.userId }).sort({ dueDate: 1 });
    res.json(tasks);
  } catch (err) {
    console.error('Ошибка получения задач:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// Добавить задачу
router.post('/', authMiddleware, async (req, res) => {
  try {
    // Валидация
    if (!req.body.title) {
      return res.status(400).json({ message: 'Название задачи обязательно' });
    }
    if (!req.body.dueDate) {
      return res.status(400).json({ message: 'Срок выполнения обязателен' });
    }

    const task = new Task({
      userId: req.user.userId,
      title: req.body.title,
      description: req.body.description,
      dueDate: req.body.dueDate,
      priority: req.body.priority,
      category: req.body.category,
      start: req.body.start,
      end: req.body.end,
    });

    const newTask = await task.save();
    res.status(201).json(newTask);
  } catch (err) {
    console.error('Ошибка создания задачи:', err);
    res.status(400).json({ message: err.message });
  }
});

// Обновить задачу
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, userId: req.user.userId });
    if (!task) {
      return res.status(404).json({ message: 'Задача не найдена или не принадлежит вам' });
    }

    // Валидация
    if (req.body.title !== undefined && !req.body.title) {
      return res.status(400).json({ message: 'Название задачи не может быть пустым' });
    }
    if (req.body.dueDate !== undefined && !req.body.dueDate) {
      return res.status(400).json({ message: 'Срок выполнения не может быть пустым' });
    }

    const updatedTask = await Task.findByIdAndUpdate(req.params.id, {
      title: req.body.title,
      description: req.body.description,
      dueDate: req.body.dueDate,
      priority: req.body.priority,
      category: req.body.category,
      start: req.body.start,
      end: req.body.end,
      completed: req.body.completed,
    }, { new: true });
    res.json(updatedTask);
  } catch (err) {
    console.error('Ошибка обновления задачи:', err);
    res.status(400).json({ message: err.message });
  }
});

// Удалить задачу
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, userId: req.user.userId });
    if (!task) {
      return res.status(404).json({ message: 'Задача не найдена или не принадлежит вам' });
    }

    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Задача удалена' });
  } catch (err) {
    console.error('Ошибка удаления задачи:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;